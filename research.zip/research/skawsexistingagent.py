import boto3
from semantic_kernel.agents import BedrockAgent, BedrockAgentThread
from semantic_kernel import Kernel
from semantic_kernel.contents import ChatMessageContent
import asyncio

bedrock_client = boto3.client("bedrock", region_name="us-east-1")
bedrock_agent_client = boto3.client("bedrock-agent", region_name="us-east-1")
agent_id = "1LPFJBZZOU"
agent_info = bedrock_agent_client.get_agent(agentId=agent_id)["agent"]
bedrock_runtime_client = boto3.client("bedrock-agent-runtime", region_name="us-east-1")

bedrock_sk_agent = BedrockAgent(
    agent_model=agent_info,
    bedrock_client=bedrock_client,
    bedrock_agent_client=bedrock_agent_client,
    bedrock_runtime_client=bedrock_runtime_client
)
agent_thread = BedrockAgentThread(bedrock_runtime_client)
kernel = Kernel() # Initialize your Semantic Kernel instance

# ... (Add any necessary plugins or services to your kernel if the Bedrock Agent uses them)

user_query = "Hello, can you help me to do automation testing with Python?"


# Define a wrapper function for the agent


# Define a wrapper function for the agent
async def bedrock_agent_function(query: str):
    # Ensure the thread session is started so thread.id is not None
    if agent_thread.id is None:
        await agent_thread._create()
    async for response in bedrock_sk_agent.invoke(query, thread=agent_thread):
        if isinstance(response, ChatMessageContent):
            return response.content
        else:
            return str(response)



async def main():
    # Call the agent wrapper function directly
    result = await bedrock_agent_function(user_query)
    print(result)

asyncio.run(main())