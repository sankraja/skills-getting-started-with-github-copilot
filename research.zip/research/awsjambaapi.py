import boto3
from semantic_kernel import Kernel
from semantic_kernel.connectors.ai.bedrock import BedrockChatCompletion
import asyncio

# Create boto3 clients for Bedrock
runtime_client = boto3.client("bedrock-runtime", region_name="us-east-1")
client = boto3.client("bedrock", region_name="us-east-1")

# Create kernel
kernel = Kernel()

# Add Bedrock service with Jamba model
bedrock_service = BedrockChatCompletion(
    model_id="ai21.jamba-1-5-mini-v1:0",
    runtime_client=runtime_client,
    client=client
)

kernel.add_service(bedrock_service)

# Use the model
async def main():
    response = await kernel.invoke_prompt(
        "What are the key features of the Jamba 1.5 Mini model?"
    )
    print(response)

asyncio.run(main())
