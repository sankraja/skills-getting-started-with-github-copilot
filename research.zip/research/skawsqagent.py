# semantic_kernel_bedrock_agent.py
import asyncio
import json
import uuid
from typing import Optional, Dict, Any, List
from datetime import datetime

import boto3
from semantic_kernel import Kernel
from semantic_kernel.functions import kernel_function
from semantic_kernel.connectors.ai.open_ai import OpenAIChatCompletion
from semantic_kernel.prompt_template import PromptTemplateConfig
from semantic_kernel.functions.kernel_arguments import KernelArguments

class BedrockAgentPlugin:
    """Semantic Kernel plugin for Amazon Bedrock Agent integration"""
    
    def __init__(self, region_name: str = 'us-east-1'):
        self.bedrock_agent_runtime = boto3.client(
            'bedrock-agent-runtime',
            region_name=region_name
        )
    
    @kernel_function(
        description="Invoke Amazon Bedrock Agent to process user queries",
        name="invoke_bedrock_agent"
    )
    async def invoke_bedrock_agent(
        self,
        query: str,
        agent_id: str,
        agent_alias_id: str,
        session_id: Optional[str] = None
    ) -> str:
        """
        Invoke a Bedrock agent with the given query
        
        Args:
            query: The user's query to send to the Bedrock agent
            agent_id: The Bedrock agent ID
            agent_alias_id: The agent alias ID
            session_id: Session ID for conversation continuity
            
        Returns:
            The agent's response as a string
        """
        try:
            if not session_id:
                session_id = str(uuid.uuid4())
            
            response = self.bedrock_agent_runtime.invoke_agent(
                agentId=agent_id,
                agentAliasId=agent_alias_id,
                sessionId=session_id,
                inputText=query
            )
            
            # Process the streaming response
            response_text = ""
            event_stream = response['completion']
            
            for event in event_stream:
                if 'chunk' in event:
                    chunk = event['chunk']
                    if 'bytes' in chunk:
                        response_text += chunk['bytes'].decode('utf-8')
            
            return response_text
            
        except Exception as e:
            return f"Error invoking Bedrock agent: {str(e)}"

    @kernel_function(
        description="Get information about Bedrock agent aliases",
        name="list_agent_aliases"
    )
    async def list_agent_aliases(self, agent_id: str) -> str:
        """List all aliases for a given Bedrock agent"""
        try:
            bedrock_agent = boto3.client('bedrock-agent')
            response = bedrock_agent.list_agent_aliases(agentId=agent_id)
            
            aliases = []
            for alias in response.get('agentAliasSummaries', []):
                aliases.append({
                    'aliasId': alias['agentAliasId'],
                    'aliasName': alias['agentAliasName'],
                    'description': alias.get('description', ''),
                    'agentVersion': alias.get('agentVersion', '')
                })
            
            return json.dumps(aliases, indent=2)
            
        except Exception as e:
            return f"Error listing agent aliases: {str(e)}"

class SemanticKernelBedrockAgent:
    """Main class for Semantic Kernel integration with Bedrock agents"""
    
    def __init__(self, region_name: str = 'us-east-1', openai_api_key: Optional[str] = None):
        self.region_name = region_name
        self.kernel = Kernel()
        
        # Add OpenAI service (optional, for enhanced planning capabilities)
        if openai_api_key:
            self.kernel.add_service(
                OpenAIChatCompletion(
                    ai_model_id="gpt-4",
                    api_key=openai_api_key
                )
            )
        
        # Import the Bedrock Agent plugin
        self.bedrock_plugin = BedrockAgentPlugin(region_name)
        self.kernel.add_plugin(self.bedrock_plugin, plugin_name="BedrockAgent")
        
        # Add time plugin for context
        self._add_time_plugin()
    
    def _add_time_plugin(self):
        """Add a simple time plugin for context"""
        class TimePlugin:
            @kernel_function(description="Get current time", name="get_current_time")
            async def get_current_time(self) -> str:
                return datetime.now().isoformat()
        
        self.kernel.add_plugin(TimePlugin(), plugin_name="Time")
    
    async def process_user_query(
        self,
        user_query: str,
        agent_id: str,
        agent_alias_id: str,
        session_id: Optional[str] = None
    ) -> str:
        """Process a user query using the Bedrock agent"""
        try:
            # Get the Bedrock agent function
            bedrock_function = self.kernel.get_function("BedrockAgent", "invoke_bedrock_agent")
            
            arguments = KernelArguments(
                query=user_query,
                agent_id=agent_id,
                agent_alias_id=agent_alias_id,
                session_id=session_id or str(uuid.uuid4())
            )
            
            result = await self.kernel.invoke(bedrock_function, arguments)
            return str(result)
            
        except Exception as e:
            return f"Error processing query: {str(e)}"
    
    async def process_with_planning(
        self,
        user_query: str,
        agent_id: str,
        agent_alias_id: str,
        context: Optional[Dict[str, Any]] = None
    ) -> str:
        """Process query with enhanced planning and context"""
        
        # Create a sophisticated prompt template
        prompt_template = """
        You are an AI assistant that can help users by leveraging Amazon Bedrock agents.
        You have access to the following functions:
        - BedrockAgent.invoke_bedrock_agent: To query Bedrock agents
        - BedrockAgent.list_agent_aliases: To get agent information
        - Time.get_current_time: To get current time
        
        Current Context: {{$context}}
        Current Time: {{$current_time}}
        User Query: {{$user_query}}
        Agent ID: {{$agent_id}}
        Agent Alias ID: {{$agent_alias_id}}
        
        Please process this query using the most appropriate approach. If you need to call
        the Bedrock agent, use the invoke_bedrock_agent function. Provide a comprehensive
        and helpful response.
        """
        
        # Get current time for context
        time_function = self.kernel.get_function("Time", "get_current_time")
        current_time = await self.kernel.invoke(time_function)
        
        # Create function from prompt
        prompt_config = PromptTemplateConfig(
            template=prompt_template,
            name="bedrock_planning",
            description="Plan and execute Bedrock agent queries"
        )
        
        planning_function = self.kernel.create_function_from_prompt(
            prompt_template=prompt_template,
            function_name="bedrock_planning"
        )
        
        arguments = KernelArguments(
            user_query=user_query,
            agent_id=agent_id,
            agent_alias_id=agent_alias_id,
            context=json.dumps(context or {}),
            current_time=str(current_time)
        )
        
        result = await self.kernel.invoke(planning_function, arguments)
        return str(result)
    
    async def conversational_flow(
        self,
        queries: List[str],
        agent_id: str,
        agent_alias_id: str
    ) -> List[Dict[str, Any]]:
        """Process multiple queries in a conversational flow"""
        session_id = str(uuid.uuid4())
        responses = []
        
        for query in queries:
            response = await self.process_user_query(
                query, agent_id, agent_alias_id, session_id
            )
            
            responses.append({
                'query': query,
                'response': response,
                'timestamp': datetime.now().isoformat(),
                'session_id': session_id
            })
        
        return responses
    
    async def get_agent_info(self, agent_id: str) -> str:
        """Get information about available agent aliases"""
        list_function = self.kernel.get_function("BedrockAgent", "list_agent_aliases")
        arguments = KernelArguments(agent_id=agent_id)
        result = await self.kernel.invoke(list_function, arguments)
        return str(result)

class BedrockAgentManager:
    """Utility class for managing Bedrock agents"""
    
    def __init__(self, region_name: str = 'us-east-1'):
        self.bedrock_agent = boto3.client('bedrock-agent', region_name=region_name)
        self.bedrock_agent_runtime = boto3.client('bedrock-agent-runtime', region_name=region_name)
    
    def create_agent(
        self,
        agent_name: str,
        agent_role_arn: str,
        foundation_model: str,
        instruction: str,
        description: Optional[str] = None
    ) -> Dict[str, Any]:
        """Create a new Bedrock agent"""
        try:
            response = self.bedrock_agent.create_agent(
                agentName=agent_name,
                agentResourceRoleArn=agent_role_arn,
                foundationModel=foundation_model,
                instruction=instruction,
                description=description or f"Agent created for {agent_name}",
                idleSessionTTLInSeconds=1800
            )
            return response['agent']
        except Exception as e:
            print(f"Error creating agent: {e}")
            return {}
    
    def list_agents(self) -> List[Dict[str, Any]]:
        """List all available Bedrock agents"""
        try:
            response = self.bedrock_agent.list_agents()
            return response.get('agentSummaries', [])
        except Exception as e:
            print(f"Error listing agents: {e}")
            return []

# Usage examples
async def main():
    """Main function demonstrating usage"""
    
    # Initialize the Semantic Kernel Bedrock Agent
    # Note: Add your OpenAI API key if you want enhanced planning capabilities
    agent = SemanticKernelBedrockAgent(
        region_name='us-east-1',
        # openai_api_key='your-openai-api-key'  # Optional
    )
    
    # Your Bedrock agent details (replace with actual values)
    agent_id = 'your-agent-id'
    agent_alias_id = 'your-agent-alias-id'
    
    try:
        print("=== Simple Query Processing ===")
        response1 = await agent.process_user_query(
            "What are the latest AWS service updates?",
            agent_id,
            agent_alias_id
        )
        print(f"Response 1: {response1}")
        
        print("\n=== Query with Context ===")
        context = {
            'user_role': 'developer',
            'experience': 'intermediate',
            'focus': 'serverless applications'
        }
        
        response2 = await agent.process_with_planning(
            "How should I optimize my serverless application costs?",
            agent_id,
            agent_alias_id,
            context
        )
        print(f"Response 2: {response2}")
        
        print("\n=== Conversational Flow ===")
        queries = [
            "What is Amazon Bedrock?",
            "How can I use it for building chatbots?",
            "What are the pricing considerations?",
            "Can you provide a simple implementation example?"
        ]
        
        conversation = await agent.conversational_flow(queries, agent_id, agent_alias_id)
        for i, exchange in enumerate(conversation, 1):
            print(f"\nExchange {i}:")
            print(f"Query: {exchange['query']}")
            print(f"Response: {exchange['response'][:200]}...")  # Truncated for display
        
        print("\n=== Agent Information ===")
        agent_info = await agent.get_agent_info(agent_id)
        print(f"Agent Info: {agent_info}")
        
    except Exception as e:
        print(f"Error in main: {e}")

# Advanced usage with custom plugins
class CustomAnalyticsPlugin:
    """Custom plugin for analytics and reporting"""
    
    @kernel_function(
        description="Analyze conversation patterns",
        name="analyze_conversation"
    )
    async def analyze_conversation(self, conversation_data: str) -> str:
        """Analyze conversation patterns and provide insights"""
        try:
            data = json.loads(conversation_data)
            
            analysis = {
                'total_exchanges': len(data),
                'average_response_length': sum(len(item.get('response', '')) for item in data) / len(data),
                'common_topics': ['AWS', 'Bedrock', 'AI'],  # Simplified analysis
                'timestamp_range': {
                    'start': data[0].get('timestamp') if data else None,
                    'end': data[-1].get('timestamp') if data else None
                }
            }
            
            return json.dumps(analysis, indent=2)
            
        except Exception as e:
            return f"Error analyzing conversation: {str(e)}"

async def advanced_usage_example():
    """Advanced usage with custom plugins"""
    
    agent = SemanticKernelBedrockAgent()
    
    # Add custom analytics plugin
    analytics_plugin = CustomAnalyticsPlugin()
    agent.kernel.add_plugin(analytics_plugin, plugin_name="Analytics")
    
    # Your agent details
    agent_id = 'your-agent-id'
    agent_alias_id = 'your-agent-alias-id'
    
    # Run a conversation
    queries = ["Tell me about AWS Lambda", "How does it integrate with other services?"]
    conversation = await agent.conversational_flow(queries, agent_id, agent_alias_id)
    
    # Analyze the conversation
    analytics_function = agent.kernel.get_function("Analytics", "analyze_conversation")
    analysis_result = await agent.kernel.invoke(
        analytics_function,
        KernelArguments(conversation_data=json.dumps(conversation))
    )
    
    print("Conversation Analysis:")
    print(analysis_result)

if __name__ == "__main__":
    # Run the main example
    asyncio.run(main())
    
    # Uncomment to run advanced example
    # asyncio.run(advanced_usage_example())
