import boto3
import zipfile
import os
import time

# Lambda deployment settings

# --- Lambda deployment settings ---
# Set these via environment variables or edit directly below
LAMBDA_FUNCTION_NAME = os.getenv('LAMBDA_FUNCTION_NAME', 'remote-mcp-server')
LAMBDA_HANDLER = os.getenv('LAMBDA_HANDLER', 'remote-mcp-server.lambda_handler')
LAMBDA_ROLE_ARN = os.getenv('LAMBDA_ROLE_ARN', 'arn:aws:iam::461646943161:role/lambda-execution-role')  # Must be set
LAMBDA_RUNTIME = os.getenv('LAMBDA_RUNTIME', 'python3.11')
LAMBDA_TIMEOUT = int(os.getenv('LAMBDA_TIMEOUT', '90'))
LAMBDA_MEMORY = int(os.getenv('LAMBDA_MEMORY', '512'))


MINIMAL_REQUIREMENTS = [
    'boto3>=1.34.0',
    'fastmcp',
]

def create_lambda_deployment_package():
    import shutil
    import subprocess
    build_dir = 'build'
    if os.path.exists(build_dir):
        shutil.rmtree(build_dir)
    os.makedirs(build_dir)
    shutil.copy('remote-mcp-server.py', build_dir)
    req_path = os.path.join(build_dir, 'requirements.txt')
    with open(req_path, 'w') as f:
        f.write('\n'.join(MINIMAL_REQUIREMENTS))
    # Use pip from venv if available, else fallback to system pip
    pip_path = os.path.join('.venv', 'Scripts', 'pip') if os.path.exists('.venv') else 'pip'
    subprocess.check_call([
        pip_path, 'install', '-r', req_path, '-t', build_dir
    ])
    with zipfile.ZipFile('remote-mcp-server.zip', 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(build_dir):
            for file in files:
                file_path = os.path.join(root, file)
                arcname = os.path.relpath(file_path, build_dir)
                zipf.write(file_path, arcname)
    print("✅ Created deployment package: remote-mcp-server.zip with minimal dependencies.")

def deploy_lambda_function():
    lambda_client = boto3.client('lambda')
    with open('remote-mcp-server.zip', 'rb') as zip_file:
        zip_content = zip_file.read()
    if not LAMBDA_ROLE_ARN or '<YOUR_LAMBDA_EXECUTION_ROLE_ARN>' in LAMBDA_ROLE_ARN:
        raise Exception("Set LAMBDA_ROLE_ARN to a valid Lambda execution role ARN.")
    try:
        response = lambda_client.update_function_code(
            FunctionName=LAMBDA_FUNCTION_NAME,
            ZipFile=zip_content
        )
        lambda_client.update_function_configuration(
            FunctionName=LAMBDA_FUNCTION_NAME,
            Runtime=LAMBDA_RUNTIME,
            Handler=LAMBDA_HANDLER,
            Timeout=LAMBDA_TIMEOUT,
            MemorySize=LAMBDA_MEMORY
        )
        print(f"✅ Updated existing Lambda function: {LAMBDA_FUNCTION_NAME}")
    except lambda_client.exceptions.ResourceNotFoundException:
        response = lambda_client.create_function(
            FunctionName=LAMBDA_FUNCTION_NAME,
            Runtime=LAMBDA_RUNTIME,
            Role=LAMBDA_ROLE_ARN,
            Handler=LAMBDA_HANDLER,
            Code={'ZipFile': zip_content},
            Description='FastMCP Lambda',
            Timeout=LAMBDA_TIMEOUT,
            MemorySize=LAMBDA_MEMORY,
            Publish=True
        )
        print(f"✅ Created new Lambda function: {LAMBDA_FUNCTION_NAME}")
    return response['FunctionArn']

def create_lambda_function_url():
    lambda_client = boto3.client('lambda')
    try:
        response = lambda_client.create_function_url_config(
            FunctionName=LAMBDA_FUNCTION_NAME,
            AuthType='NONE',
            Cors={
                'AllowOrigins': ['*'],
                'AllowMethods': ['*'],
                'AllowHeaders': ['*']
            }
        )
        print(f"✅ Created Function URL: {response['FunctionUrl']}")
    except lambda_client.exceptions.ResourceConflictException:
        response = lambda_client.get_function_url_config(FunctionName=LAMBDA_FUNCTION_NAME)
        print(f"ℹ️  Function URL already exists: {response['FunctionUrl']}")
    return response['FunctionUrl']

def main():
        print("""
        --- FastMCP Lambda Deployment Script ---
        This script will:
            1. Package remote-mcp-server.py and dependencies
            2. Deploy to AWS Lambda (create or update)
            3. Create a Function URL for public HTTP access

        Usage:
            Set environment variables for your deployment (see top of script), or edit them directly.
            python deploy_lambda_url.py

        Required:
            - LAMBDA_ROLE_ARN: IAM role ARN with Lambda execution permissions
        """)
        create_lambda_deployment_package()
        deploy_lambda_function()
        url = create_lambda_function_url()
        print(f"\n🎉 Lambda Function URL: {url}")
        return url

if __name__ == "__main__":
    main()
