# === Imports ===


import os
import asyncio
import boto3
import asyncio
import time
import json
from botocore.exceptions import ClientError
from contextlib import AsyncExitStack
from semantic_kernel.agents import BedrockAgent, BedrockAgentThread
from semantic_kernel.contents import FunctionCallContent, FunctionResultContent
from semantic_kernel.contents.chat_message_content import ChatMessageContent
from semantic_kernel.connectors.mcp import MCPStdioPlugin, MCPStreamableHttpPlugin

# === Bedrock Clients ===
bedrock_client = boto3.client("bedrock", region_name="us-east-1")
bedrock_agent_client = boto3.client("bedrock-agent", region_name="us-east-1")
bedrock_runtime_client = boto3.client("bedrock-agent-runtime", region_name="us-east-1")

# === Agent Instructions ===
AGENT_INSTRUCTIONS = """
You are an automation testing assistant specialized in API and Web UI testing using Playwright MCP. Follow these guidelines:

Test Generation: Create Playwright test scripts based on user prompts for APIs or web interfaces.
Execution Support: Guide users on running tests via MCP, including browser/device configurations.
Result Analysis: Help interpret test results, identify failures, and suggest fixes.
Prompt Handling: Respond to natural language queries about test creation, debugging, and automation strategies.
"""

# === User Inputs ===
USER_INPUTS = [
    "Navigate to google.com and search for Playwright GitHub repository. Open the repository link and list the names of all files in the root directory."
]


REGION = "us-east-1"
ROLE_POLICY_NAME = "AmazonBedrockExecutionPolicy"

def create_agent_role(postfix, model_id):
    """Create IAM role for the agent with Bedrock permissions"""
    iam_resource = boto3.resource("iam", region_name=REGION)
    role_name = f"AmazonBedrockExecutionRoleForAgents_{postfix}"
    model_arn = f"arn:aws:bedrock:{REGION}::foundation-model/{model_id}*"
    agent_arn = f"arn:aws:bedrock:{REGION}:*:agent/*"

    print("Creating an execution role for the agent...")

    try:
        role = iam_resource.create_role(
            RoleName=role_name,
            AssumeRolePolicyDocument=json.dumps({
                "Version": "2012-10-17",
                "Statement": [{
                    "Effect": "Allow",
                    "Principal": {"Service": "bedrock.amazonaws.com"},
                    "Action": "sts:AssumeRole",
                }]
            }),
        )

        role.Policy(ROLE_POLICY_NAME).put(
            PolicyDocument=json.dumps({
                "Version": "2012-10-17",
                "Statement": [
                    {
                        "Effect": "Allow",
                        "Action": [
                            "bedrock:InvokeModel",
                            "bedrock:InvokeAgent"
                        ],
                        "Resource": [model_arn, agent_arn],
                    }
                ]
            })
        )
        return role.arn
    except ClientError as e:
        if e.response['Error']['Code'] == 'EntityAlreadyExists':
            print(f"Role {role_name} already exists. Using existing role.")
            role = iam_resource.Role(role_name)
            return role.arn
        else:
            print(f"Couldn't create role {role_name}. Here's why: {e}")
            raise

async def create_bedrock_agent(plugins=None):
    agent_name = "agent-with-playwrigth-mcp"
    agent_alias_name = agent_name  # Use same name for alias
    foundation_model = "ai21.jamba-1-5-mini-v1:0"
    postfix = "ondemand"  # You may want to generate this dynamically
    # Create the IAM role and get its ARN
    agent_role_arn = create_agent_role(postfix, foundation_model)

    async def wait_for_agent_status(agent_id, desired_status, timeout=60):
        for _ in range(timeout):
            try:
                agent = bedrock_agent_client.get_agent(agentId=agent_id)["agent"]
                status = agent.get("agentStatus")
                if status == desired_status:
                    return True
                print(f"Waiting for agent {agent_id} to reach status {desired_status} (current: {status})...")
            except Exception as e:
                print(f"Error polling agent status: {e}")
            await asyncio.sleep(2)
        raise RuntimeError(f"Timed out waiting for agent {agent_id} to reach status {desired_status}")

    async def delete_agent_if_exists(agent_name):
        existing_agents = bedrock_agent_client.list_agents().get("agentSummaries", [])
        for agent in existing_agents:
            if agent.get("agentName") == agent_name:
                agent_id = agent["agentId"]
                print(f"Deleting existing agent: {agent_name} (id: {agent_id})")
                try:
                    bedrock_agent_client.delete_agent(agentId=agent_id)
                except Exception as e:
                    print(f"Error deleting agent: {e}")
                # Wait for deletion
                for _ in range(30):
                    agents = bedrock_agent_client.list_agents().get("agentSummaries", [])
                    if not any(a.get("agentName") == agent_name for a in agents):
                        print(f"Agent {agent_name} deleted.")
                        return
                    print("Waiting for agent deletion...")
                    await asyncio.sleep(2)
                raise RuntimeError(f"Timed out waiting for agent {agent_name} to be deleted.")

    async def prepare_agent(agent_id):
        print(f"Preparing agent {agent_id}...")
        try:
            bedrock_agent_client.prepare_agent(agentId=agent_id)
        except Exception as e:
            print(f"Error preparing agent: {e}")
        await wait_for_agent_status(agent_id, "PREPARED")

    async def create_alias(agent_id, alias_name):
        print(f"Creating alias '{alias_name}' for agent {agent_id}")
        try:
            # Fetch published agent versions
            versions_resp = bedrock_agent_client.list_agent_versions(agentId=agent_id)
            published_versions = [v for v in versions_resp.get("agentVersionSummaries", []) if v.get("agentVersionStatus") == "PUBLISHED"]
            if not published_versions:
                print(f"No published versions found for agent {agent_id}. Cannot create alias.")
                return
            # Use the latest published version (by version number)
            latest_version = max(published_versions, key=lambda v: v.get("agentVersion", ""))
            version_str = latest_version["agentVersion"]
            alias_response = bedrock_agent_client.create_agent_alias(
                agentId=agent_id,
                agentAliasName=alias_name,
                routingConfiguration=[{"agentVersion": version_str}]
            )
            print(f"Alias created: {alias_response.get('agentAliasId', 'unknown')}")
        except Exception as e:
            print(f"Error creating alias: {e}")

    # Main agent creation flow
    await delete_agent_if_exists(agent_name)
    try:
        create_response = bedrock_agent_client.create_agent(
            agentName=agent_name,
            agentResourceRoleArn=agent_role_arn,
            foundationModel=foundation_model,
            instruction=AGENT_INSTRUCTIONS,
            description="Automation testing assistant for Playwright MCP",
            idleSessionTTLInSeconds=1800
        )
        agent_info = create_response["agent"]
        agent_id = agent_info["agentId"]
    except Exception as e:
        raise RuntimeError(f"Failed to create agent: {e}")

    await wait_for_agent_status(agent_id, "NOT_PREPARED")
    await prepare_agent(agent_id)
    await create_alias(agent_id, agent_alias_name)

    return BedrockAgent(
        agent_model=agent_info,
        bedrock_client=bedrock_client,
        bedrock_agent_client=bedrock_agent_client,
        bedrock_runtime_client=bedrock_runtime_client,
        plugins=plugins,
    )
def prepare_agent(self):
        """Prepare the agent for use"""
        print("Preparing the agent...")

        agent_id = self.agent["agentId"]
        prepared_agent_details = self.bedrock_wrapper.prepare_agent(agent_id)
        self.wait_for_agent_status(agent_id, "PREPARED")

        return prepared_agent_details

def wait_for_agent_status(self, agent_id, status):
    """Wait for agent to reach desired status"""
    while self.bedrock_wrapper.get_agent(agent_id)["agentStatus"] != status:
        time.sleep(2)

def create_mcp_plugins() -> list:
    return [
        # MCPStreamableHttpPlugin(
        #     name="github".replace("-", "_"),
        #     description="MCP server for github",
        #     url="https://api.githubcopilot.com/mcp/",
        #     headers = {
        #         "Authorization": "Bearer " + os.environ["YOUR_AUTH_TOKEN"],
        #     },
        # ),
        MCPStdioPlugin(
            name="playwright".replace("-", "_"),
            description="MCP server for playwright",
            command="npx",
            args=[
                "@playwright/mcp@latest",
            ],
            env={}
        )
    ]

async def connect_mcp_plugins(stack: AsyncExitStack) -> list:
    mcp_plugins = create_mcp_plugins()
    print(f"Created {len(mcp_plugins)} MCP plugins")
    print("Connecting to MCP servers...")
    connected_plugins = []
    for i, plugin in enumerate(mcp_plugins):
        print(f"Connecting to {plugin.name}...")
        connected_plugin = await stack.enter_async_context(plugin)
        connected_plugins.append(connected_plugin)
        print(f"{plugin.name} connected successfully.")
    print(f"All {len(connected_plugins)} MCP servers connected!")
    return connected_plugins

async def handle_intermediate_steps(message: ChatMessageContent) -> None:
    if message.items:
        for item in message.items:
            if isinstance(item, FunctionResultContent):
                print(f"Function Result:> {item.result} for function: {item.name}")
            elif isinstance(item, FunctionCallContent):
                print(f"Function Call:> {item.name} with arguments: {item.arguments}")
            else:
                print(f"{item}")

# === Main Agent Function ===
async def bedrock_agent_function(connected_plugins: list):
    bedrock_sk_agent = await create_bedrock_agent(connected_plugins)
    agent_thread = BedrockAgentThread(bedrock_runtime_client)
    if agent_thread.id is None:
        await agent_thread._create()
    for user_input in USER_INPUTS:
        print(f"\n# User: '{user_input}'")
        async for response_chunk in bedrock_sk_agent.invoke(
            messages=user_input,
            thread=agent_thread,
        ):
            if response_chunk and response_chunk.content:
                print(f"# [Model Response] {response_chunk.content}")
            if hasattr(response_chunk, 'thread') and response_chunk.thread:
                agent_thread = response_chunk.thread
    print("\n--- All tasks completed successfully ---")

# === Main Entrypoint ===
async def main():
    async with AsyncExitStack() as stack:
        connected_plugins = await connect_mcp_plugins(stack)
        await bedrock_agent_function(connected_plugins)
    await asyncio.sleep(0.5)

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\nProgram interrupted by user")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")
        import traceback
        traceback.print_exc()
    finally:
        print("Program finished.")
