import json
import asyncio
from typing import Dict, Any

# Your MCP tools as regular functions (Lambda doesn't need FastMCP)
def calculate(operation: str, num1: float, num2: float) -> Dict[str, Any]:
    """Calculator tool"""
    try:
        if operation.lower() == "add":
            result = num1 + num2
        elif operation.lower() == "subtract":
            result = num1 - num2
        elif operation.lower() == "multiply":
            result = num1 * num2
        elif operation.lower() == "divide":
            result = num1 / num2 if num2 != 0 else "Error: Division by zero"
        else:
            return {"error": "Invalid operation. Use: add, subtract, multiply, divide"}
        
        return {
            "operation": operation,
            "operands": [num1, num2],
            "result": result
        }
    except Exception as e:
        return {"error": str(e)}

def process_text(text: str, action: str) -> Dict[str, Any]:
    """Text processor tool"""
    try:
        if action.lower() == "uppercase":
            result = text.upper()
        elif action.lower() == "lowercase":
            result = text.lower()
        elif action.lower() == "reverse":
            result = text[::-1]
        elif action.lower() == "word_count":
            result = len(text.split())
        elif action.lower() == "char_count":
            result = len(text)
        else:
            return {"error": "Invalid action. Use: uppercase, lowercase, reverse, word_count, char_count"}
        
        return {
            "original_text": text,
            "action": action,
            "result": result
        }
    except Exception as e:
        return {"error": str(e)}

# MCP Protocol Handler
def handle_mcp_request(body: Dict[str, Any]) -> Dict[str, Any]:
    """Handle MCP protocol requests"""
    method = body.get("method")
    params = body.get("params", {})
    request_id = body.get("id", 1)
    
    if method == "session/initialize":
        # Minimal session/initialize response for MCP protocol compatibility
        return {
            "jsonrpc": "2.0",
            "id": request_id,
            "result": {
                "sessionId": "dummy-session-id",
                "message": "Session initialized"
            }
        }

    if method == "tools/list":
        return {
            "jsonrpc": "2.0",
            "id": request_id,
            "result": {
                "tools": [
                    {
                        "name": "calculate",
                        "description": "Perform basic mathematical operations",
                        "inputSchema": {
                            "type": "object",
                            "properties": {
                                "operation": {"type": "string", "enum": ["add", "subtract", "multiply", "divide"]},
                                "num1": {"type": "number"},
                                "num2": {"type": "number"}
                            },
                            "required": ["operation", "num1", "num2"]
                        }
                    },
                    {
                        "name": "process_text",
                        "description": "Process text with various operations",
                        "inputSchema": {
                            "type": "object",
                            "properties": {
                                "text": {"type": "string"},
                                "action": {"type": "string", "enum": ["uppercase", "lowercase", "reverse", "word_count", "char_count"]}
                            },
                            "required": ["text", "action"]
                        }
                    }
                ]
            }
        }
    
    elif method == "tools/call":
        tool_name = params.get("name")
        arguments = params.get("arguments", {})
        
        if tool_name == "calculate":
            result = calculate(
                arguments.get("operation"),
                arguments.get("num1"),
                arguments.get("num2")
            )
        elif tool_name == "process_text":
            result = process_text(
                arguments.get("text"),
                arguments.get("action")
            )
        else:
            return {
                "jsonrpc": "2.0",
                "id": request_id,
                "error": {"code": -32601, "message": f"Tool not found: {tool_name}"}
            }
        
        return {
            "jsonrpc": "2.0",
            "id": request_id,
            "result": {
                "content": [{"type": "text", "text": json.dumps(result)}]
            }
        }
    
    else:
        return {
            "jsonrpc": "2.0",
            "id": request_id,
            "error": {"code": -32601, "message": f"Method not found: {method}"}
        }

# Lambda handler
def lambda_handler(event, context):
    """Main Lambda handler"""
    try:
        # Handle different event sources
        if 'httpMethod' in event:
            # API Gateway event
            http_method = event['httpMethod']
            path = event.get('path', '')
            
            # CORS headers
            headers = {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
                'Access-Control-Allow-Headers': 'Content-Type, Authorization'
            }
            
            # Handle OPTIONS for CORS
            if http_method == 'OPTIONS':
                return {
                    'statusCode': 200,
                    'headers': headers,
                    'body': ''
                }
            
            # Health check
            if http_method == 'GET':
                return {
                    'statusCode': 200,
                    'headers': headers,
                    'body': json.dumps({
                        'message': 'MCP Server is running!',
                        'tools': ['calculate', 'process_text']
                    })
                }
            
            # Handle MCP requests
            if http_method == 'POST':
                body = json.loads(event.get('body', '{}'))
                mcp_response = handle_mcp_request(body)
                
                return {
                    'statusCode': 200,
                    'headers': headers,
                    'body': json.dumps(mcp_response)
                }
        
        # Direct invocation
        else:
            return handle_mcp_request(event)
            
    except Exception as e:
        return {
            'statusCode': 500,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({'error': str(e)})
        }
