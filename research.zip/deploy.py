import boto3
import json
import zipfile
import os
import time

# Only include minimal dependencies for Lambda
MINIMAL_REQUIREMENTS = [
    'boto3>=1.34.0',
    'fastmcp',
    # 'rpds-py' will be provided by Lambda Layer
]

def create_lambda_deployment_package():
    """Create deployment package with minimal dependencies for Lambda"""
    import shutil
    import subprocess
    build_dir = 'build'
    if os.path.exists(build_dir):
        shutil.rmtree(build_dir)
    os.makedirs(build_dir)
    # Copy main handler
    shutil.copy('remote-mcp-server.py', build_dir)
    # Write minimal requirements.txt
    req_path = os.path.join(build_dir, 'requirements.txt')
    with open(req_path, 'w') as f:
        f.write('\n'.join(MINIMAL_REQUIREMENTS))

    # Use Docker to install dependencies for Linux x86_64 (AWS Lambda compatible)
    docker_cmd = [
        'docker', 'run', '--rm',
        '-v', f"{os.path.abspath(build_dir)}:/var/task",
        '-v', f"{os.path.abspath(req_path)}:/tmp/requirements.txt:ro",
        'lambci/lambda:build-python3.11',
        'pip', 'install', '-r', '/tmp/requirements.txt', '-t', '/var/task'
    ]
    try:
        subprocess.check_call(docker_cmd)
    except Exception as e:
        print("❌ Docker build failed. Make sure Docker Desktop is running and lambci/lambda:build-python3.11 is available.")
        raise e

    # Zip contents of build_dir
    with zipfile.ZipFile('remote-mcp-server.zip', 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(build_dir):
            for file in files:
                file_path = os.path.join(root, file)
                arcname = os.path.relpath(file_path, build_dir)
                zipf.write(file_path, arcname)
    print("✅ Created deployment package: remote-mcp-server.zip with minimal dependencies (Linux compatible).")

def deploy_lambda_function():
    """Deploy Lambda function"""
    lambda_client = boto3.client('lambda')
    
    # Read the zip file
    with open('remote-mcp-server.zip', 'rb') as zip_file:
        zip_content = zip_file.read()
    
    function_name = 'remote-mcp-server'
    
    try:
        # Try to update existing function code
        response = lambda_client.update_function_code(
            FunctionName=function_name,
            ZipFile=zip_content
        )
        # Ensure runtime is updated to python3.11
        lambda_client.update_function_configuration(
            FunctionName=function_name,
            Runtime='python3.11'
        )
        print(f"✅ Updated existing Lambda function: {function_name} and set runtime to python3.11")
    except lambda_client.exceptions.ResourceNotFoundException:
        # Create new function
        response = lambda_client.create_function(
            FunctionName=function_name,
            Runtime='python3.11',  # Updated to Python 3.11 for match statement support
            Role='arn:aws:iam::461646943161:role/lambda-execution-role',
            Handler='remote-mcp-server.lambda_handler',
            Code={'ZipFile': zip_content},
            Description='MCP Server for Bedrock Agents',
            Timeout=90,
            MemorySize=512,
            Environment={
                'Variables': {
                    'AWS_LWA_INVOKE_MODE': 'response_stream',
                    'AWS_LWA_READINESS_CHECK_PATH': '/mcp'
                }
            }
        )
        print(f"✅ Created new Lambda function: {function_name}")
    
    return response['FunctionArn']

def create_api_gateway():
    """Create API Gateway"""
    apigateway = boto3.client('apigateway')
    lambda_client = boto3.client('lambda')
    
    # Create REST API
    api_response = apigateway.create_rest_api(
        name='remote-mcp-server-api',
        description='MCP Server API for Bedrock Agents'
    )
    
    api_id = api_response['id']
    print(f"✅ Created API Gateway: {api_id}")
    
    # Get root resource
    resources = apigateway.get_resources(restApiId=api_id)
    root_id = resources['items'][0]['id']
    
    # Create /mcp resource
    mcp_resource = apigateway.create_resource(
        restApiId=api_id,
        parentId=root_id,
        pathPart='mcp'
    )
    
    mcp_resource_id = mcp_resource['id']
    
    # Get Lambda function ARN
    function_name = 'remote-mcp-server'
    lambda_response = lambda_client.get_function(FunctionName=function_name)
    lambda_arn = lambda_response['Configuration']['FunctionArn']
    
    # Create Lambda integration URI
    region = boto3.Session().region_name
    account_id = boto3.client('sts').get_caller_identity()['Account']
    lambda_uri = f"arn:aws:apigateway:{region}:lambda:path/2015-03-31/functions/{lambda_arn}/invocations"
    
    # Add GET method
    apigateway.put_method(
        restApiId=api_id,
        resourceId=mcp_resource_id,
        httpMethod='GET',
        authorizationType='NONE'
    )
    
    apigateway.put_integration(
        restApiId=api_id,
        resourceId=mcp_resource_id,
        httpMethod='GET',
        type='AWS_PROXY',
        integrationHttpMethod='POST',
        uri=lambda_uri
    )
    
    # Add POST method
    apigateway.put_method(
        restApiId=api_id,
        resourceId=mcp_resource_id,
        httpMethod='POST',
        authorizationType='NONE'
    )
    
    apigateway.put_integration(
        restApiId=api_id,
        resourceId=mcp_resource_id,
        httpMethod='POST',
        type='AWS_PROXY',
        integrationHttpMethod='POST',
        uri=lambda_uri
    )
    
    # Add OPTIONS method for CORS
    apigateway.put_method(
        restApiId=api_id,
        resourceId=mcp_resource_id,
        httpMethod='OPTIONS',
        authorizationType='NONE'
    )
    
    apigateway.put_integration(
        restApiId=api_id,
        resourceId=mcp_resource_id,
        httpMethod='OPTIONS',
        type='AWS_PROXY',
        integrationHttpMethod='POST',
        uri=lambda_uri
    )
    
    # Deploy API
    deployment = apigateway.create_deployment(
        restApiId=api_id,
        stageName='prod'
    )
    
    # Give API Gateway permission to invoke Lambda
    # Add permission for API Gateway to invoke Lambda for all stages and POST /mcp
    statement_id = f"apigateway-invoke-{api_id}"
    source_arn = f"arn:aws:execute-api:{region}:{account_id}:{api_id}/*/POST/mcp"
    try:
        lambda_client.add_permission(
            FunctionName=function_name,
            StatementId=statement_id,
            Action='lambda:InvokeFunction',
            Principal='apigateway.amazonaws.com',
            SourceArn=source_arn
        )
        print(f"✅ Added API Gateway invoke permission to Lambda for {source_arn}.")
    except lambda_client.exceptions.ResourceConflictException:
        print(f"ℹ️  API Gateway invoke permission already exists for Lambda ({statement_id}). Skipping add_permission.")
    
    # Return the endpoint URL
    endpoint_url = f"https://{api_id}.execute-api.{region}.amazonaws.com/prod/mcp"
    print(f"✅ API Gateway deployed: {endpoint_url}")
    
    return endpoint_url

def main():
    """Main deployment function"""
    print("🚀 Starting MCP Server deployment to Lambda + API Gateway...")
    
    # Step 1: Create deployment package
    create_lambda_deployment_package()
    
    # Step 2: Deploy Lambda function
    lambda_arn = deploy_lambda_function()
    
    # Step 3: Create API Gateway
    endpoint_url = create_api_gateway()
    
    print("\n🎉 Deployment completed successfully!")
    print(f"📍 MCP Endpoint: {endpoint_url}")
    print(f"🔧 Lambda ARN: {lambda_arn}")
    
    return endpoint_url

if __name__ == "__main__":
    endpoint = main()
