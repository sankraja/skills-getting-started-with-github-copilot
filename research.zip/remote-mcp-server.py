# --- FastMCP streamable MCP server implementation ---
import os
from mcp.server.fastmcp import FastMCP
import uvicorn

mcp = FastMCP(name="ProcessTextServer",     
    instructions="Use the provided tools to perform calculations and text processing tasks.",
    stateless_http=True)



@mcp.tool(
    name="process_text",
    description="Process text with various operations"   
)
def process_text(text: str, action: str):
    if action.lower() == "uppercase":
        result = text.upper()
    elif action.lower() == "lowercase":
        result = text.lower()
    elif action.lower() == "reverse":
        result = text[::-1]
    elif action.lower() == "word_count":
        result = len(text.split())
    elif action.lower() == "char_count":
        result = len(text)
    else:
        yield {"error": "Invalid action. Use: uppercase, lowercase, reverse, word_count, char_count"}
        return
    yield {"result": result}


# Create and run the MCP server

if __name__ == "__main__":
    host= os.getenv("HOST", "0.0.0.0")
    port = int(os.getenv("PORT", "8000"))
    print(f"Starting MCP server on {host}:{port}")
    mcp.run(transport="streamable-http", host=host, port=port)

def lambda_handler(event, context):
    """AWS Lambda entry point for FastMCP server."""
    return mcp.lambda_handler(event, context)
