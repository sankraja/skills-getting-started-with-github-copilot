import boto3
import json
import requests

def diagnose_api_gateway_lambda():
    api_id = "ktrfykvnxi"
    function_name = "remote-mcp-server"
    region = "us-east-1"
    
    lambda_client = boto3.client('lambda')
    apigateway_client = boto3.client('apigateway')
    
    print("🔍 Diagnosing API Gateway + Lambda Setup...")
    
    # 1. Check Lambda function exists and is active
    print("\n1️⃣ Checking Lambda function...")
    try:
        func_response = lambda_client.get_function(FunctionName=function_name)
        print(f"✅ Lambda function exists: {func_response['Configuration']['FunctionName']}")
        print(f"   Runtime: {func_response['Configuration']['Runtime']}")
        print(f"   Handler: {func_response['Configuration']['Handler']}")
        print(f"   State: {func_response['Configuration']['State']}")
    except Exception as e:
        print(f"❌ Lambda function error: {e}")
        return
    
    # 2. Check API Gateway exists
    print("\n2️⃣ Checking API Gateway...")
    try:
        api_response = apigateway_client.get_rest_api(restApiId=api_id)
        print(f"✅ API Gateway exists: {api_response['name']}")
    except Exception as e:
        print(f"❌ API Gateway error: {e}")
        return
    
    # 3. Check integration
    print("\n3️⃣ Checking integration...")
    try:
        resources = apigateway_client.get_resources(restApiId=api_id)
        mcp_resource = None
        
        for resource in resources['items']:
            if resource['pathPart'] == 'mcp':
                mcp_resource = resource
                break
        
        if mcp_resource:
            integration = apigateway_client.get_integration(
                restApiId=api_id,
                resourceId=mcp_resource['id'],
                httpMethod='POST'
            )
            print(f"✅ Integration found:")
            print(f"   Type: {integration['type']}")
            print(f"   URI: {integration['uri']}")
            
            if integration['type'] != 'AWS_PROXY':
                print("⚠️  WARNING: Integration should be AWS_PROXY for Lambda Proxy integration")
        else:
            print("❌ /mcp resource not found")
    except Exception as e:
        print(f"❌ Integration error: {e}")
    
    # 4. Test Lambda directly
    print("\n4️⃣ Testing Lambda directly...")
    test_event = {
        "httpMethod": "GET",
        "path": "/mcp",
        "headers": {"Content-Type": "application/json"},
        "body": None
    }
    
    try:
        response = lambda_client.invoke(
            FunctionName=function_name,
            Payload=json.dumps(test_event)
        )
        result = json.loads(response['Payload'].read())
        
        if 'statusCode' in result:
            print(f"✅ Lambda responds with status: {result['statusCode']}")
        else:
            print(f"❌ Lambda response: {result}")
    except Exception as e:
        print(f"❌ Lambda test error: {e}")
    
    # 5. Test API Gateway endpoint
    print("\n5️⃣ Testing API Gateway endpoint...")
    endpoint = f"https://{api_id}.execute-api.{region}.amazonaws.com/prod/mcp"
    
    try:
        response = requests.get(endpoint, timeout=10)
        print(f"✅ API Gateway responds with status: {response.status_code}")
        if response.status_code == 200:
            print(f"   Response: {response.json()}")
        else:
            print(f"   Error: {response.text}")
    except Exception as e:
        print(f"❌ API Gateway test error: {e}")
    
    print(f"\n📍 Your endpoint: {endpoint}")

if __name__ == "__main__":
    diagnose_api_gateway_lambda()
